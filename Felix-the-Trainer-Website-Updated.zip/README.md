# Felix the Trainer website

## Training prices
- Daily session: KSh 500
- Weekly package: KSh 2,000
- Monthly package: KSh 5,000

## Files
- `index.html` — responsive website
- `assets/fitness-hero.png` — fitness hero artwork

## Publish with GitHub Pages
1. Open your repository: https://github.com/peter25kim-stack/Felix-the-trainer-
2. Choose **Add file → Upload files**.
3. Upload `index.html` and the `assets` folder (including `fitness-hero.png`) together.
4. Commit the files to the `main` branch.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
7. Wait for GitHub Pages to finish publishing.

Expected URL: https://peter25kim-stack.github.io/Felix-the-trainer-/
